ALTER TYPE operation_state ADD VALUE 'pending';


BEGIN;

DROP TABLE IF EXISTS service_plans;
DROP TABLE IF EXISTS service_offerings;

COMMIT;
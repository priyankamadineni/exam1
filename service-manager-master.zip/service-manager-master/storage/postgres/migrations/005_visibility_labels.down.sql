BEGIN;

DROP TABLE IF EXISTS visibility_labels;

COMMIT;
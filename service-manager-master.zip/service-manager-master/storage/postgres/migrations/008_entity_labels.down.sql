BEGIN;

DROP TABLE IF EXISTS platform_labels;
DROP TABLE IF EXISTS service_offering_labels;
DROP TABLE IF EXISTS service_plan_labels;

COMMIT;
# Service Manager Release Notes

## v0.1.0
2018-09-19

* Initial version
